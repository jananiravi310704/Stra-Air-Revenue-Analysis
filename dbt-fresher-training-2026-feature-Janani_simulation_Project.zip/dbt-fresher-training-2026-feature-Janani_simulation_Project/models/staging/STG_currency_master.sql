
{{
    config(
        materialized = 'table',
        schema       = 'simulation_08_MART',
        tags         = ['dimension']
    )
}}

WITH source AS (
    SELECT * FROM {{ source('starair', 'CURRENCY_MASTER') }}
),

deduplication AS (
    SELECT 
        currency_code,
        description,
        ROW_NUMBER() OVER(PARTITION BY currency_code ORDER BY currency_code) AS rn
    FROM source
) 

SELECT 

    CAST(MD5(COALESCE(TRIM(UPPER(currency_code)), 'UNK')) AS VARCHAR(32)) AS currency_sk,
    CAST(COALESCE(TRIM(UPPER(currency_code)), 'UNK') AS VARCHAR(3))       AS currency_code_nk,
    CAST(COALESCE(TRIM(description), 'UNK') AS VARCHAR(50))               AS description,
    CAST(CURRENT_TIMESTAMP::TIMESTAMP_NTZ AS TIMESTAMP_NTZ)               AS dw_updated_at
FROM deduplication
WHERE rn = 1