{{
    config(
        materialized = 'incremental',
        schema       = 'simulation_08_STAGE',
        unique_key   = ['ticket_number'],
        tags         = ['exception']
    )
}}

SELECT
    carrier_code,
    ticket_number,
    agent_code,
    sale_date,
    sales_currency,
    tax_1_amount,
    tax_2_amount,
    tax_3_amount,
    tax_total_amount,
    COALESCE(tax_1_amount,0) + COALESCE(tax_2_amount,0)
        + COALESCE(tax_3_amount,0)                     AS computed_tax_total,
    ABS(
        COALESCE(tax_1_amount,0) + COALESCE(tax_2_amount,0)
        + COALESCE(tax_3_amount,0) - COALESCE(tax_total_amount,0)
    )                                               AS variance,
    'TAX_SUM_MISMATCH'                              AS exc_reason,
    CURRENT_TIMESTAMP::TIMESTAMP_NTZ                AS exc_timestamp,

FROM {{ ref('TF_sales') }}
WHERE tax_reconciliation_flag = 1

{% if is_incremental() %}
AND sale_date >= (SELECT MAX(sale_date)  FROM {{ this }})
{% endif %}