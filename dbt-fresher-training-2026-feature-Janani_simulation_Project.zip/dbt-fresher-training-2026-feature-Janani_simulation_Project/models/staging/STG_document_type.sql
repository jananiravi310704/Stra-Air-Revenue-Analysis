WITH source AS (
    SELECT * FROM {{ source('starair', 'DOCUMENT_TYPE') }}
)
select 

    COALESCE(UPPER(TRIM(Document_type)), 'UNK' ) as Document_type,
    COALESCE(LOWER(TRIM(Description)), 'UNK') as Description
    from source