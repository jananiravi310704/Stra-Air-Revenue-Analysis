WITH source AS (
    SELECT * FROM {{ source('starair', 'TAX_TYPE_MASTER') }}
)
select 
    COALESCE(CAST(NULLIF(TRIM(UPPER(tax_type)), '') AS VARCHAR(2)), 'T') AS tax_type,
COALESCE(CAST(NULLIF(TRIM(INITCAP(tax_type_description)), '') AS VARCHAR(20)), 'UNK') AS tax_type_description
    from source