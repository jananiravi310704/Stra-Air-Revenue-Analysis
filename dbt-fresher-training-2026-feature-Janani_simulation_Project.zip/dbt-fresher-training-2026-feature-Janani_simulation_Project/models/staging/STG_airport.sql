WITH source AS (
    SELECT * FROM {{ source('starair', 'AIRPORT_MASTER') }})

select
        COALESCE(NULLIF(TRIM(UPPER(sl_no)), ''), '0') as sl_no,
        COALESCE(CAST(NULLIF(TRIM(UPPER(airport_code)), '') AS VARCHAR(3)), 'UNK') AS airport_code,
        COALESCE(CAST(NULLIF(TRIM(UPPER(airport_code)), '') AS VARCHAR(3)), 'UNK') AS airport_code_nk,
        COALESCE(CAST(NULLIF(TRIM(airport_name), '') AS VARCHAR(100)), 'UNK') AS airport_name,
        COALESCE(NULLIF(TRIM(UPPER(city_code)), ''), 'UNK') as city_code,
        COALESCE(NULLIF(TRIM(UPPER(country)), ''), 'UNK') as country_name,
        COALESCE(NULLIF(TRIM(UPPER(country_code)), ''), 'UNK') as country_code
from source 
where city_code <> 'GRX'