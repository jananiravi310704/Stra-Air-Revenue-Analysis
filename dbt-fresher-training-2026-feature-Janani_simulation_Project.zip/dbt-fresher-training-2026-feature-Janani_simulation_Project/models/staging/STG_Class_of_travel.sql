
WITH source AS (
    SELECT * FROM {{ source('starair', 'CLASS_OF_TRAVEL') }}
)
select 

    COALESCE(CAST(NULLIF(TRIM(UPPER(CLASS_OF_TRAVEL)), '') AS VARCHAR(10)), 'UNK') AS class_of_travel,

    COALESCE(CAST(NULLIF(TRIM(cot_description), '') AS VARCHAR(100)), 'UNK') AS cot_description,
    from source

