WITH source AS (
    SELECT * FROM {{ source('starair', 'INWARD') }}),
valid_records as (select * from source 
where Ticket_no 
in ( 
        select ticket_number from {{ ref('STG_Sales') }} 
        group by ticket_number
        having count(*) =1 
) 
 )
select
    coalesce(cast(Billed_Carrier_code as bigint), 0) as billed_carrier_code,
    coalesce(cast(Carrier_code as bigint), 0) as carrier_code,
     COALESCE(CAST(Ticket_no AS NUMBER(10,0)), 0)   as ticket_no,
    COALESCE(CAST(Coupon_no AS NUMBER(1,0)), 1)  as coupon_no,
    coalesce(cast(Billed_date as date), cast('1900-01-01' as date)) as billed_date,
    coalesce(cast(Stage  AS NUMBER(1,0)), 0) as stage,
    coalesce(trim(upper(cast(Billed_currency as varchar))), 'UNK') as billed_currency,
    COALESCE(CAST(Billed_coupon_amount AS NUMBER(18,4)), 0)                                    AS billed_coupon_amt,
    COALESCE(CAST(Billed_commission_amount AS NUMBER(18,4)), 0)                                AS billed_commission_amt,
    COALESCE(CAST(Billed_discount_amout AS NUMBER(18,4)), 0)                                   AS billed_discount_amt,
    COALESCE(CAST(Accepted_coupon_amount AS NUMBER(18,4)), 0)                                  AS accepted_coupon_amt,
    COALESCE(CAST(Accepted_Comission_amount AS NUMBER(18,4)), 0)                               AS accepted_commission_amt,
    COALESCE(CAST(Accepted_discount_amount AS NUMBER(18,4)), 0)                                AS accepted_discount_amt,
    ABS(COALESCE(CAST(Rejected_coupon_amount AS NUMBER(18,4)), 0))                                  AS rejected_coupon_amt,
    ABS(COALESCE(CAST(Rejected_commission_amount AS NUMBER(18,4)), 0) )                             AS rejected_commission_amt,
    ABS(COALESCE(CAST(Rejected_discount_amount AS NUMBER(18,4)), 0)) AS rejected_discount_amt
from  valid_records