
WITH src AS (SELECT * FROM {{ source('starair', 'CITY_MASTER') }})
SELECT
    COALESCE(CAST(NULLIF(TRIM(UPPER(City_Code)), '') AS VARCHAR(3)), 'UNK') AS city_code,
COALESCE(CAST(NULLIF(INITCAP(TRIM(City_Name)), '') AS VARCHAR(50)), 'UNK') AS city_name,
    INITCAP(TRIM(country_name))  AS country_name
FROM src

WHERE lookup_value <> 72  