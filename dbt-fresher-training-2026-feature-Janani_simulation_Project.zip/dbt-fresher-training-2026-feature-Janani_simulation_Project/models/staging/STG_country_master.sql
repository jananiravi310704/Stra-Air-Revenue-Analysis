
WITH src AS (SELECT * FROM {{ source('starair', 'COUNTRY_MASTER') }})

SELECT
    COALESCE(CAST(Country_Number AS NUMBER(5,0)), -1) AS country_number, 
    COALESCE(CAST(NULLIF(TRIM(UPPER(Country_Code)), '') AS VARCHAR(2)), 'UNK') AS country_code, 
    COALESCE(CAST(NULLIF(INITCAP(TRIM(Country_Name)), '') AS VARCHAR(50)), 'UNK') AS country_name 
FROM src
WHERE Country_Number IS NOT NULL