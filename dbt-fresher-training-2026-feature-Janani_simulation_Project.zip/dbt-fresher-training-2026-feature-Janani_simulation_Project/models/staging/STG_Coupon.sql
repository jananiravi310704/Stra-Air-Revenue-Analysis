WITH source AS (
    SELECT * FROM {{ source('starair', 'COUPON') }}),
valid_records as (
                    select * 
                    from source 
                    where Ticket_Number in 
                                        (select ticket_number
                                        from {{ ref('STG_Sales') }}
                                        group by ticket_number
                                        having count(*)=1 
                                        )                        
)
SELECT
    COALESCE(NULLIF(TRIM(UPPER(CAST(Carrier_Code AS VARCHAR(3)))), ''), 'UNK') AS carrier_code,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Ticket_Number AS VARCHAR(10)))), ''), 'UNK') AS ticket_number,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Coupon_Number AS VARCHAR(2)))), ''), 'UNK') AS coupon_number,
    COALESCE(NULLIF(TRIM(UPPER(CAST(From_Airport AS VARCHAR(5)))), ''), 'UNK') AS from_airport,
    COALESCE(NULLIF(TRIM(UPPER(CAST(To_Airport AS VARCHAR(5)))), ''), 'UNK') AS to_airport,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Coupon_Status AS VARCHAR(3)))), ''), 'UNK') AS coupon_status,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Closed_Carrier AS VARCHAR(5)))), ''), 'UNK') AS closed_carrier,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Uplift_Carrier AS VARCHAR(5)))), ''), 'UNK') AS uplift_carrier,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Flight_no AS VARCHAR(3)))), ''), 'UNK') AS flight_no,
    COALESCE(TO_DATE(Flight_Date), CAST('1900-01-01' AS DATE)) AS flight_date,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Class_of_Travel AS VARCHAR))), ''), 'UNK') AS class_of_travel,
    COALESCE(NULLIF(TRIM(UPPER(CAST(RBD_Code AS VARCHAR))), ''), 'UNK') AS rbd_code,
    COALESCE(NULLIF(TRIM(UPPER(CAST(Fare_Currency_Code AS VARCHAR))), ''), 'UNK') AS fare_currency_code,
    COALESCE(CAST(Coupon_Amount_in_Sale_currency AS NUMBER(18, 2)), 0.00) AS coupon_amount_in_sale_currency,
    COALESCE(CAST(Coupon_commission_in_Sale_Currency AS NUMBER(18, 2)), 0.00) AS coupon_commission_in_sale_currency,
    COALESCE(CAST(Coupon_discount_in_Sale_Currency AS NUMBER(18, 2)), 0.00) AS coupon_discount_in_sale_currency,
    COALESCE(CAST(Coupon_amount_in_base_currency AS NUMBER(18, 2)), 0.00) AS coupon_amount_in_base_currency,
    COALESCE(CAST(Coupon_commission_in_Base_Currency AS NUMBER(18, 2)), 0.00) AS coupon_commission_in_base_currency,
    COALESCE(CAST(Coupon_discount_in_Base_Currency AS NUMBER(18, 2)), 0.00) AS coupon_discount_in_base_currency,
    COALESCE(CAST(Coupon_Amount_in_Billing_currency AS NUMBER(18, 2)), 0.00) AS coupon_amount_in_billing_currency,
    COALESCE(CAST(Coupon_commission_in_Billing_Currency AS NUMBER(18, 2)), 0.00) AS coupon_commission_in_billing_currency,
    COALESCE(CAST(Coupon_discount_in_Billing_Currency AS NUMBER(18, 2)), 0.00) AS coupon_discount_in_billing_currency,
    COALESCE(CAST(MPA_Value_in_Base_currency AS NUMBER(18, 2)), 0.00) AS mpa_value_in_base_currency
FROM valid_records