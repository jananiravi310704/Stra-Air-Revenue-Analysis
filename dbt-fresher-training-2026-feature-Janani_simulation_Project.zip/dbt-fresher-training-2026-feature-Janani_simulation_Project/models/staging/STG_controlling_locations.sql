
WITH src AS (SELECT * FROM {{ source('starair', 'CONTROLLING_LOCATIONS') }})

SELECT
    COALESCE(CAST(NULLIF(TRIM(Ctrl_Loc_Code), '') AS VARCHAR(10)), 'UNK')     AS ctrl_loc_code,
    COALESCE(CAST(NULLIF(TRIM(Ctrl_Loc_Name), '') AS VARCHAR(100)), 'UNK')   AS ctrl_loc_name,
    COALESCE(CAST(NULLIF(UPPER(TRIM(City_code)), '') AS VARCHAR(3)), 'UNK')  AS ctrl_loc_city_code, 
    COALESCE(CAST(NULLIF(UPPER(TRIM(Location_Type)), '') AS VARCHAR(5)), 'UNK') AS ctrl_loc_location_type, 
    COALESCE(CAST(NULLIF(TRIM(Country), '') AS VARCHAR(2)), 'UNK')            AS ctrl_loc_country_code 
FROM src
