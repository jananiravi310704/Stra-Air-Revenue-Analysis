WITH source AS (
    SELECT * FROM {{ source('starair', 'CREDIT_CARD_MASTER') }}
)
select 

    COALESCE(UPPER(TRIM(cc_company)) ,'UNK') as cc_company,
    COALESCE(TRIM(description), 'UNK') as description
    from source