{{
    config(
        materialized = 'incremental',
        schema       = 'simulation_08_STAGE',
        unique_key   = 'ticket_number',
        merge_exclude_columns='exc_timestamp',
        tags         = ['exception']
    )
}}

SELECT
    ticket_number,
    agent_code,
    sales_currency,
    sale_date,
    ticket_amount,
    commission_amount,
    tax_code_1,
    fop_1_code,
    CASE
        WHEN ticket_amount = 0     THEN 'ZERO_AMOUNT'
        ELSE                            'NEGATIVE_AMOUNT'
    END                                             AS exc_reason,
    CURRENT_TIMESTAMP::TIMESTAMP_NTZ                AS exc_timestamp

FROM {{ ref('STG_Sales') }}
WHERE COALESCE(ticket_amount, 0) <= 0

{% if is_incremental() %}
AND sale_date >= (SELECT MAX(sale_date)  FROM {{ this }})
{% endif %}
