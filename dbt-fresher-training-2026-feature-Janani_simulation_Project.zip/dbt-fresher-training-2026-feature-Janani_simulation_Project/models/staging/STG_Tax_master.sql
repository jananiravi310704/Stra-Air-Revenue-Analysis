WITH source AS (
    SELECT * FROM {{ source('starair', 'TAX_MASTER') }}
)
select 
    COALESCE(CAST(NULLIF(TRIM(UPPER(Tax_code)), '') AS VARCHAR(5)), 'UNK') AS tax_code,
    COALESCE(CAST(NULLIF(TRIM(UPPER(Tax_code)), '') AS VARCHAR(5)), 'UNK') AS tax_code_nk,
    COALESCE(CAST(NULLIF(TRIM(description), '') AS VARCHAR(100)), 'UNK') AS description,
    COALESCE(CAST(NULLIF(TRIM(description), '') AS VARCHAR(100)), 'UNK') AS tax_description,
    COALESCE(trim(UPPER(country_code)), 'UNK') as country_code,
    COALESCE(trim(UPPER(type)), 'UNK') as type
    from source