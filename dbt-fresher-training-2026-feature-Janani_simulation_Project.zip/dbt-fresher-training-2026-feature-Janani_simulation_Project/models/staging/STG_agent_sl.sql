
WITH source AS (
    SELECT * FROM {{ source('starair', 'AGENT_SL_MASTER') }}
),
renamed_and_null_handled AS (
    SELECT
    COALESCE(CAST(NULLIF(UPPER(TRIM(agent_code)), '') AS VARCHAR(10)), 'UNK') AS agent_code_nk,
    COALESCE(CAST(NULLIF(initcap(TRIM(agent_name)), '') AS VARCHAR(100)), 'UNK') AS agent_name,   
    COALESCE(CAST(NULLIF(UPPER(TRIM(agent_city)), '') AS VARCHAR(5)), 'UNK') AS agent_city_code,
    COALESCE(CAST(NULLIF(TRIM(agent_city), '') AS VARCHAR(50)), 'UNK') AS agent_city_name,
    COALESCE(CAST(NULLIF(TRIM(agent_address), '') AS VARCHAR(255)), 'UNK') AS agent_address, 
   CAST(COALESCE(NULLIF(UPPER(TRIM(Location_Type)), ''), 'UNK') AS VARCHAR(5)) AS location_type,
    COALESCE(CAST(NULLIF(TRIM(Ctrl_location), '') AS VARCHAR(10)), 'UNK') AS ctrl_location 
    FROM source
)

SELECT * FROM renamed_and_null_handled
