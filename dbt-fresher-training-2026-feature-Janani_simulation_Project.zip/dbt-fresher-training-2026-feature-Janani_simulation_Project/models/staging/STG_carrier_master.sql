
WITH src AS (SELECT * FROM {{ source('starair', 'CARRIER_MASTER') }})

    SELECT
        COALESCE(CAST(Carrier_Number AS NUMBER(5,0)), -1) AS carrier_number_nk,
    COALESCE(CAST(NULLIF(TRIM(UPPER(Carrier_Code)), '') AS VARCHAR(3)), 'UNK') AS carrier_code,
    COALESCE(CAST(NULLIF(INITCAP(TRIM(Airline_Name)), '') AS VARCHAR(100)), 'UNK') AS Airline_Name,
    COALESCE(CAST(NULLIF(INITCAP(TRIM(Country)), '') AS VARCHAR(50)), 'UNK') AS country
FROM src
WHERE Carrier_Number IS NOT NULL

