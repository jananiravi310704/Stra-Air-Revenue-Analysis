
WITH source AS (
    SELECT * FROM {{ source('starair', 'CURRENCY_EXCHANGE_RATE_MASTER') }}
)
select 
        COALESCE(NULLIF(UPPER(TRIM(from_currency)), ''), 'UNK') as from_currency,
        COALESCE(NULLIF((UPPER(To_currency)), ''), 'UNK') as To_currency,
        COALESCE(NULLIF(UPPER(TRIM(Rate_type)), ''), 'UNK') as Rate_type,
        COALESCE(TRY_CAST(Exchange_Rate AS FLOAT),0) as Exchange_rate,
        coalesce(to_date(effective_date_from), cast('1900-01-01' as date)) as effective_date_from,
        coalesce(to_date(effective_date_to), cast('1900-01-01' as date)) as effective_date_to
    from source

