WITH source AS (
    SELECT * FROM {{ source('starair', 'UPLIFT') }}
),
valid_records as (
                    select *  
                    from source
                    where ticket_number 
                    in ( 
                    select ticket_number from {{ ref('STG_Sales') }} 
                    group by ticket_number
                    having count(*) =1 
                    ) 
                    and carrier_code = 888 
)

select
    coalesce(cast(Carrier_Code as bigint), 0) as carrier_code,
    coalesce(cast(Ticket_Number as bigint), 0) as ticket_number,
    coalesce(cast(Coupon_Number as bigint), 0) as coupon_number,
    coalesce(cast(Flight_no as bigint), 0) as flight_no,
    coalesce(cast(Flight_Date as date), cast('1900-01-01' as date)) as flight_date,
    coalesce(trim(upper(cast(Class_of_Travel as varchar))), 'UNK') as class_of_travel,
    coalesce(trim(upper(cast(From_Airport as varchar))), 'UNK') as from_airport,
    coalesce(trim(upper(cast(To_Airport as varchar))), 'UNK') as to_airport
from valid_records
