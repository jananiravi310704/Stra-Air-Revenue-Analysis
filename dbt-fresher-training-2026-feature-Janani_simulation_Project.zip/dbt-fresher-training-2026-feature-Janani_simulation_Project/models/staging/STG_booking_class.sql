with book_class as( select * from {{ source('starair', 'BOOKING_CLASS') }})
SELECT 
    COALESCE(CAST(NULLIF(TRIM(UPPER(RBD_CODE)), '') AS VARCHAR(3)), 'UN') AS rbd_code,
    COALESCE(CAST(NULLIF(TRIM(UPPER(RBD_CODE)), '') AS VARCHAR(3)), 'UNK') AS rbd_code_nk,
    COALESCE(CAST(NULLIF(TRIM(UPPER(CLASS_OF_TRAVEL)), '') AS VARCHAR(10)), 'UNK') AS class_of_travel,
    CAST(NULLIF(TRIM(RBD_Desciption), '') AS VARCHAR(100)) AS rbd_description,
    FROM book_class

   