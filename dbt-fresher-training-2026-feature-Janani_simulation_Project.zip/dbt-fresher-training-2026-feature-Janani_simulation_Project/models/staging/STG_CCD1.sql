WITH source AS (
    SELECT * FROM {{ source('starair', 'CCD1') }}
),
valid_records as ( select * from source where ticket_no in (
                select ticket_number
                from {{ ref('STG_Sales') }}
                group by ticket_number
                having count(*)=1)
)
select
    COALESCE(CAST(Airline_No AS VARCHAR), 'UNK') AS airline_no,
    COALESCE(CAST(Ticket_No AS VARCHAR), 'UNK')  AS ticket_no,
    COALESCE(TRIM(UPPER(CAST(Country_Code AS VARCHAR))), 'UNK') AS country_code,
    COALESCE(TRIM(UPPER(CAST(Sale_Currency_Code AS VARCHAR))), 'UNK') AS sale_currency_code,
    COALESCE(CAST(Sale_Valu AS NUMBER(18,4)), 0)     AS sale_value,
    COALESCE(TRIM(UPPER(CAST(Billing_Currency_Code AS VARCHAR))), 'UNK') AS billing_currency_code,
    COALESCE(CAST(Billing_Value AS NUMBER(18,4)), 0) AS billing_value,
    COALESCE(upper(TRIM(CAST(Card_Type AS VARCHAR))), 'UNK') AS card_type,
    COALESCE(TRIM(UPPER(CAST(Invoice_No AS VARCHAR))), 'UNK')  AS invoice_no,
    COALESCE(TRY_TO_DATE(CAST(invoice_date AS VARCHAR)), '1900-01-01'::DATE)    AS invoice_date,
    COALESCE(TRIM(initcap(CAST(SaleRefund AS VARCHAR))), 'UNK')                   AS sale_refund,
    COALESCE(TRY_TO_DATE(CAST(chargeback_date AS VARCHAR)), '1900-01-01'::DATE) AS chargeback_date,
    COALESCE(CAST(Chargeback_Amt AS NUMBER(18,4)), 0) AS chargeback_amt
from valid_records