WITH source AS (
    SELECT * FROM {{ source('starair', 'SALES') }}
),

valid_records AS (
    SELECT ticket_number 
    FROM source 
    GROUP BY ticket_number
    HAVING COUNT(*) = 1    
),

valid_flag AS (
    SELECT 
        *,
        CASE 
            WHEN Ticket_Number IN (SELECT * FROM valid_records) THEN 1 
            ELSE 0 
        END AS valid_record 
    FROM source
)

   SELECT
    COALESCE(CAST(NULLIF(TRIM(UPPER(Carrier_Code)), '') AS VARCHAR(5)), 'UNK') AS carrier_code,
    COALESCE(CAST(NULLIF(TRIM(Ticket_Number), '') AS VARCHAR(20)), 'UNK') AS ticket_number,
    COALESCE(CAST(NULLIF(TRIM(UPPER(Sales_Currency)), '') AS VARCHAR(3)), 'UNK') AS sales_currency,
    COALESCE(CAST(Ticket_Amount AS NUMBER(18, 2)), 0.00) AS ticket_amount,
    COALESCE(CAST(NULLIF(TRIM(Agent_Code), '') AS VARCHAR(10)), 'UNK') AS agent_code,
    COALESCE(CAST(NULLIF(TRIM(UPPER(Agent_City_Code)), '') AS VARCHAR(5)), 'UNK') AS agent_city_code,
    COALESCE(CAST(Sale_Date AS DATE), CAST('1900-01-01' AS DATE)) AS sale_date,
    COALESCE(CAST(Commission_Amount AS NUMBER(18, 2)), 0.00) AS commission_amount,
    COALESCE(CAST(Discount_Amount AS NUMBER(18, 2)), 0.00) AS discount_amount,
    COALESCE(CAST(TAX_Amount AS NUMBER(18, 2)), 0.00) AS tax_amount,
    COALESCE(CAST(NULLIF(TRIM(UPPER(Tax_Code_1)), '') AS VARCHAR(5)), 'UNK') AS tax_code_1,
    COALESCE(CAST(Tax_1_Amount AS NUMBER(18, 2)), 0.00) AS tax_1_amount,
    CAST(NULLIF(TRIM(UPPER(Tax_code_2)), '') AS VARCHAR(5)) AS tax_code_2,
    COALESCE(CAST(Tax_2_Amount AS NUMBER(18, 2)), 0.00) AS tax_2_amount,
    COALESCE(TRIM(UPPER(CAST(Tax_Code_3 AS VARCHAR(5)))), 'UNK') AS tax_code_3,
    COALESCE(CAST(Tax_3_Amount AS NUMBER(18, 2)), 0.00) AS tax_3_amount,
    COALESCE(TRIM(UPPER(CAST(FOP_1_Code AS VARCHAR(5)))), 'UNK') AS fop_1_code,
    COALESCE(CAST(FOP_1_Amount AS NUMBER(18, 2)), 0.00) AS fop_1_amount,
    COALESCE(TRIM(UPPER(CAST(FOP_2 AS VARCHAR(5)))), 'UNK') AS fop_2_code,
    COALESCE(CAST(FOP_2_Amount AS NUMBER(18, 2)), 0.00) AS fop_2_amount,
    COALESCE(TRIM(UPPER(CAST(FOP_3 AS VARCHAR(5)))), 'UNK') AS fop_3_code,
    COALESCE(CAST(FOP_3_Amount AS NUMBER(18, 2)), 0.00) AS fop_3_amount,
    COALESCE(CAST(NULLIF(TRIM(UPPER(Flight_year_Quarter)), '') AS VARCHAR(10)), 'UNK') AS flight_year_quarter
FROM valid_flag
WHERE valid_record = 1
