WITH source AS (
    SELECT * FROM {{ source('starair', 'DOCUMENT_ASSIGNMENT_MASTER') }}
)
select 

        COALESCE(NULLIF(TRIM(Document_code), ''), 'UNK') as Document_code,
        COALESCE(NULLIF(TRIM(UPPER(Document_type)), ''), 'UNK') as Document_type,
        COALESCE(TRY_CAST(No_of_coupons AS INT), 0) as No_of_coupons
    from source