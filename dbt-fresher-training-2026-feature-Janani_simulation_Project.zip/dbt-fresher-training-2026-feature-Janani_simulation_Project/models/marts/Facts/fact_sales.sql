{{
    config(
        materialized='incremental',
        unique_key='ticket_sk',
       merge_exclude_columns= 'dw_created_at',
        tags =['fact']
    )

}}

with src AS (
                SELECT * FROM {{ ref('TF_sales') }}
                {% if is_incremental() %}
                WHERE sale_date >= TO_DATE(
            CAST(COALESCE((SELECT MAX(sale_date_sk) FROM {{ this }}), 19000101) AS VARCHAR), 
                'YYYYMMDD')
                {% endif %}
),
dim_date    AS (SELECT date_sk,          full_date        FROM {{ ref('Dim_date') }}),
dim_agent   AS (SELECT agent_sk,         agent_code_nk    FROM {{ ref('Dim_agent') }}),
dim_carrier AS (SELECT carrier_sk,       carrier_number_nk  FROM {{ ref('Dim_carrier') }}),
dim_xr      AS (
    SELECT from_currency,to_currency, exchange_rate,effective_date_from,effective_date_to
    FROM {{ ref('Dim_exchange_rate') }}    
)

SELECT
        MD5(s.ticket_number|| '|' ||s.sale_date) AS  ticket_sk,
        d.date_sk                                AS   sale_date_sk,
        a.agent_sk                               AS  agent_sk,
        c.carrier_sk                             AS carrier_sk,
        s.ticket_number                     AS ticket_number_nk,
        s.sales_currency                           AS sales_currency,
        s.sale_date,
        s.fop_1_code AS fop_1_code,
        s.fop_2_code,
        s.fop_3_code,
        s.tax_code_1,
        s.tax_code_2,                      
        s.tax_code_3,                     
        s.ticket_type           AS ticket_type,
        s.flight_year_quarter,
        s.tax_reconciliation_flag,         
        s.ticket_amt_sale      AS ticket_amt_sale,
        s.commission_amt_sale AS commission_amt_sale,
        s.discount_amt_sale  AS discount_amt_sale,
        s.tax_1_amount   AS tax_1_amt,
        s.tax_2_amount             AS tax_2_amt,
        s.tax_3_amount             AS tax_3_amt,
        s.tax_total_amount         AS tax_total_amt,
        s.fop_1_amount             AS fop_1_amt,
        s.fop_2_amount             AS fop_2_amt,
        s.fop_3_amount           AS fop_3_amt,
        case 
        when s.sales_currency = 'AED' then s.ticket_amt_sale 
        when s.sales_currency <> 'AED' then  
        ROUND(
            s.ticket_amt_sale * xr.exchange_rate,
            2
        )         end                         AS ticket_amt_base,
        case 
        when   s.sales_currency = 'AED' then s.commission_amt_sale
        when s.sales_currency <> 'AED' then   
         ROUND(
            s.commission_amt_sale * xr.exchange_rate,
            2
        )           end                        AS commission_amt_base,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ    AS dw_loaded_at

FROM src s
LEFT JOIN dim_date    d  ON s.sale_date      = d.full_date
LEFT JOIN dim_agent   a  ON s.agent_code     = a.agent_code_nk
LEFT JOIN dim_carrier c  ON s.carrier_code   = c.carrier_number_nk
LEFT JOIN dim_xr     xr  ON s.sales_currency = xr.from_currency and xr.to_currency='AED' 
                            and (  s.sale_date  >= xr.effective_date_from and  s.sale_date  <= xr.effective_date_to )
