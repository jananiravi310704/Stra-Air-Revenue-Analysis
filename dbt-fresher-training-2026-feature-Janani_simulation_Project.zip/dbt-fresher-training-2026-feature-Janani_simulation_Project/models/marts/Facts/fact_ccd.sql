{{
    config(
        materialized         = 'incremental',
        unique_key           = 'ccd_sk',
        incremental_strategy = 'merge',
        cluster_by           = ['invoice_date_sk', 'carrier_sk'],
        tags                 = ['fact']
    )
}}

WITH
src AS (
    SELECT * FROM {{ ref('TF_CCD') }}
    {% if is_incremental() %}
    WHERE TRY_CAST(TO_VARCHAR(invoice_date, 'YYYYMMDD') AS INTEGER)
          >= COALESCE((SELECT MAX(invoice_date_sk) - 3 FROM {{ this }}), 0)
    {% endif %}
),

dim_date AS (
    SELECT date_sk, full_date
    FROM {{ ref('Dim_date') }}
),
dim_carr AS (
    SELECT carrier_sk, carrier_number_nk
    FROM {{ ref('Dim_carrier') }}
)

SELECT
    MD5(s.airline_no || '|' ||s.ticket_no || '|' ||s.invoice_no)   AS ccd_sk,
    d.date_sk AS invoice_date_sk,
    ca.carrier_sk       AS carrier_sk,
    s.billing_currency_code   ,
    s.ticket_no                                                 AS ticket_number_nk,
    s.invoice_no,
    s.invoice_date,
     COALESCE(s.sale_refund, 'Sale')                             AS sale_refund_flag,
    s.card_type,
    s.payment_category,
    s.country_code,
    COALESCE(s.sale_value,    0)                                AS sale_value,
    COALESCE(s.billing_value, 0)                                AS billing_value,
    s.chargeback_amt,
    s.chargeback_date,
    CURRENT_TIMESTAMP::TIMESTAMP_NTZ                            AS dw_loaded_at

FROM src s
LEFT JOIN dim_date d
    ON  s.invoice_date = d.full_date
LEFT JOIN dim_carr ca
    ON  CAST(s.airline_no AS NUMBER) = ca.carrier_number_nk
