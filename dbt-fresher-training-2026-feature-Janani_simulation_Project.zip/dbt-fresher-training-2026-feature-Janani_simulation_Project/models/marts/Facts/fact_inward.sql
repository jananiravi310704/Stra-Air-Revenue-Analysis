{{
    config(
        materialized         = 'incremental',
        unique_key           = 'inward_sk',
        incremental_strategy = 'merge',
        tags                 = ['fact']
    )
}}

WITH
src AS (
    SELECT * FROM {{ ref('TF_inward') }}
    {% if is_incremental() %}
    WHERE billed_date >= COALESCE(
    (SELECT TO_DATE(CAST(MAX(billed_date_sk) AS VARCHAR), 'YYYYMMDD') FROM {{ this }}),
    '1900-01-01'::DATE
)
    {% endif %})
,

dim_date AS (SELECT date_sk, full_date                              FROM {{ ref('Dim_date') }}),
dim_carr AS (SELECT carrier_sk, carrier_number_nk, Carrier_code    FROM {{ ref('Dim_carrier') }}),
dim_xr      AS (
    SELECT from_currency,to_currency, exchange_rate,effective_date_from,effective_date_to
    FROM {{ ref('Dim_exchange_rate') }}    
)
SELECT
  
    MD5(s.billed_carrier_code || '|' || s.ticket_no || '|' || s.coupon_no || '|' || s.billed_date)  AS inward_sk,
    d.date_sk AS billed_date_sk,
    bcarr.carrier_sk AS billed_carrier_sk,
    scarr.carrier_sk AS star_air_carrier_sk,
    s.billed_currency    ,
    s.ticket_no             AS ticket_number_nk,
    s.coupon_no             AS coupon_number_nk,
    s.dispute_stage,     
    s.billed_date,
    s.billed_coupon_amt,
    s.billed_commission_amt,
    s.billed_discount_amt,
    s.accepted_coupon_amt,
    s.accepted_coupon_amt * ex.exchange_rate as accepted_coupon_amt_base,   
    s.accepted_commission_amt,
    s.accepted_discount_amt,
    s.rejected_coupon_amt,  
    s.rejected_commission_amt,
    s.rejected_discount_amt,

    CURRENT_TIMESTAMP::TIMESTAMP_NTZ    AS dw_loaded_at

FROM src s
LEFT JOIN dim_date d ON s.billed_date = d.full_date
LEFT JOIN dim_carr bcarr ON CAST(s.billed_carrier_code AS NUMBER) = bcarr.carrier_number_nk
LEFT JOIN dim_carr scarr ON CAST(s.carrier_code AS NUMBER) = scarr.carrier_number_nk
                        AND scarr.carrier_number_nk = 888
left join dim_xr ex on s.billed_currency=ex.from_currency and ex.to_currency='AED'
and (s.billed_date>=ex.effective_date_from and s.billed_date<=ex.effective_date_to)
