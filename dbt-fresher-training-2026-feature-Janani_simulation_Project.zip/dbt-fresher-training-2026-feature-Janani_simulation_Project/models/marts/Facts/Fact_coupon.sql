{{
    config(
        materialized         = 'incremental',
        unique_key           = 'segment_sk',
        incremental_strategy = 'merge',
        tags                 = ['fact']
    )
}}

WITH
src AS (
    SELECT * FROM {{ ref('TF_coupon') }}
    {% if is_incremental() %}
    WHERE flight_date >= TO_DATE(
        CAST(COALESCE((SELECT MAX(flight_date_sk) FROM DBT_TRAINING.simulation_08_MART.Fact_coupon), 19000101) AS VARCHAR), 
        'YYYYMMDD')
    {% endif %}
    ),

dim_date AS (SELECT date_sk, full_date                           FROM {{ ref('Dim_date') }}),
dim_carr AS (SELECT carrier_sk, carrier_number_nk                 FROM {{ ref('Dim_carrier') }}),
dim_apt  AS (SELECT airport_sk, airport_code_nk                 FROM {{ ref('Dim_airport') }}),
dim_flt  AS (SELECT flight_sk, flight_number_nk, flight_date_nk FROM {{ ref('Dim_flight') }}),
dim_bc   AS (SELECT booking_class_sk, rbd_code_nk               FROM {{ ref('Dim_booking_class') }})


SELECT
      MD5(s.carrier_code || '|' || s.ticket_number || '|' || s.coupon_number)   AS segment_sk,

    d.date_sk                                 AS flight_date_sk,
    ca.carrier_sk                            AS carrier_sk,
    orig.airport_sk          AS from_airport_sk,
    dest.airport_sk         AS to_airport_sk,
     COALESCE(flt.flight_sk,'UNK') as flight_sk ,                     
    bc.booking_class_sk      AS booking_class_sk,
    s.fare_currency_code,
    s.ticket_number                                       AS ticket_number_nk,
    s.coupon_number                                        AS coupon_number_nk,
    s.coupon_status,
    s.airline_route,          
    s.flight_date,             
    COALESCE(s.coupon_amount_in_sale_currency,    0)       AS coupon_amt_sale,
    COALESCE(s.coupon_commission_in_sale_currency,   0)       AS coupon_comm_sale,
    COALESCE(s.coupon_discount_in_sale_currency,   0)       AS coupon_disc_sale,
    COALESCE(s.coupon_amount_in_base_currency,    0)       AS coupon_amt_base,
    COALESCE(s.coupon_commission_in_base_currency,   0)       AS coupon_comm_base,
    COALESCE(s.coupon_discount_in_base_currency,   0)       AS coupon_disc_base,
    COALESCE(s.coupon_amount_in_billing_currency, 0)       AS coupon_amt_billing,
    COALESCE(s.coupon_commission_in_billing_currency,0)       AS coupon_comm_billing,
    COALESCE(s.coupon_discount_in_billing_currency,0)       AS coupon_disc_billing,
    COALESCE(s.mpa_value_in_base_currency,     0)       AS mpa_value_base,
    CURRENT_TIMESTAMP::TIMESTAMP_NTZ        AS dw_loaded_at

FROM src s
LEFT JOIN dim_date d    ON s.flight_date   = d.full_date
LEFT JOIN dim_carr ca   ON s.carrier_code  = ca.carrier_number_nk
LEFT JOIN dim_apt  orig ON s.from_airport  = orig.airport_code_nk
LEFT JOIN dim_apt  dest ON s.to_airport    = dest.airport_code_nk
LEFT JOIN dim_flt  flt  ON s.flight_no     = flt.flight_number_nk
                       AND s.flight_date   = flt.flight_date_nk
LEFT JOIN dim_bc   bc   ON s.rbd_code      = bc.rbd_code_nk

