{{
    config(
        materialized         = 'incremental',
        unique_key           = 'boarding_sk',
        incremental_strategy = 'merge',
        tags                 = ['fact']
    )
}}

WITH
src AS (
    SELECT * FROM {{ ref('TF_uplift') }}
    {% if is_incremental() %}
    WHERE flight_date >= TO_DATE(
        CAST(COALESCE((SELECT MAX(flight_date_sk) FROM DBT_TRAINING.simulation_08_MART.fact_uplift), 19000101) AS VARCHAR), 
        'YYYYMMDD'
    )
    {% endif %}
),

dim_date AS (SELECT date_sk, full_date                              FROM {{ ref('Dim_date') }}),
dim_carr AS (SELECT carrier_sk, carrier_number_nk                    FROM {{ ref('Dim_carrier') }}),
dim_apt  AS (SELECT airport_sk, airport_code_nk                    FROM {{ ref('Dim_airport') }}),
dim_flt  AS (SELECT flight_sk, flight_number_nk, flight_date_nk    FROM {{ ref('Dim_flight') }})


SELECT

    MD5( s.carrier_code || '|' || s.ticket_number || '|' || s.coupon_number || '|' || s.flight_date)  AS boarding_sk,

    d.date_sk   AS flight_date_sk,
    ca.carrier_sk   AS carrier_sk,
    orig.airport_sk AS from_airport_sk,
    dest.airport_sk  AS to_airport_sk,
    flt.flight_sk,
    s.flight_date,
    s.ticket_number         AS ticket_number_nk,
    s.coupon_number         AS coupon_number_nk,
    s.class_of_travel,     
    s.pax_boarded_count,   

    CURRENT_TIMESTAMP::TIMESTAMP_NTZ    AS dw_loaded_at,


FROM src s
LEFT JOIN dim_date d   ON s.flight_date  = d.full_date
LEFT JOIN dim_carr ca  ON s.carrier_code = ca.carrier_number_nk
LEFT JOIN dim_apt orig ON s.from_airport = orig.airport_code_nk
LEFT JOIN dim_apt dest ON s.to_airport   = dest.airport_code_nk
LEFT JOIN dim_flt flt  ON s.flight_no    = flt.flight_number_nk
                      AND s.flight_date  = flt.flight_date_nk

