{{
    config(
        materialized = 'incremental',
        unique_key = 'airport_sk',
        incremental_strategy = 'merge',
        merge_exclude_columns = ['dw_created_at'],
        tags = ['dimension']
    )
}}

WITH src AS (
    SELECT * FROM {{ ref('TF_airport') }}
)

SELECT
            md5(src.airport_code_nk) as airport_sk,
            src.airport_code_nk,
            src.airport_name,
            src.city_code,
            src.city_name,
            src.country_code,
            src.country_name,
            src.country_number,
            CURRENT_TIMESTAMP as dw_created_at,
            {% if is_incremental() %}
    case when t.airport_sk  is null then null 
    else CURRENT_TIMESTAMP end as dw_updated_at
    {%else%}
    null as dw_updated_at
    {% endif %}
            from src
{% if is_incremental() %}
left join {{ this  }} t
 on  md5(src.airport_code_nk)= t.airport_sk
{% endif %}
