{{
    config(materialized='incremental', 
    unique_key='agent_sk',
    merge_exclude_columns = ['dw_created_at'],
    tags=['dimension'])
}}
WITH src AS (SELECT * FROM {{ ref('TF_agent_enriched') }})

    SELECT
        MD5(src.agent_code_nk) AS agent_sk,
         src.agent_code_nk,
        src.agent_name, 
        src.agent_city_code, 
        src.agent_address, 
        src.location_type,
        src.ctrl_loc_code, 
        src.ctrl_loc_name, 
        src.ctrl_loc_city_code,
        src.ctrl_loc_location_type, 
        src.ctrl_loc_country_code,
        src.country_code, 
        src.country_name, 
         CURRENT_TIMESTAMP  as dw_created_at,
        {% if is_incremental() %}
        case when t.agent_sk  is null then null 
        else CURRENT_TIMESTAMP end as dw_updated_at
        {%else%}
        null as dw_updated_at
        {% endif %}
        
    FROM src
    {% if is_incremental() %}
    left join {{ this }} t
    on MD5(src.agent_code_nk)= t.agent_sk
{% endif %}


