

{{
    config(
        materialized = 'table',
        tags         = ['dimension']
    )
}}

WITH spine AS (
    {{
        dbt_utils.date_spine(
            datepart   = "day",
            start_date = "cast('2015-01-01' as date)",
            end_date   = "cast('2036-01-01' as date)"
        )
    }}
),

attributes AS (
    SELECT
        CAST(TO_VARCHAR(date_day, 'YYYYMMDD') AS NUMBER(8,0))                  AS date_sk,
        CAST(date_day AS DATE)                                                 AS full_date,
        CAST(DAY(date_day) AS NUMBER(2,0))                                     AS day,
        CAST(MONTH(date_day) AS NUMBER(2,0))                                   AS month_num,
        CAST(MONTHNAME(date_day) AS VARCHAR(10))                               AS month_name,
        CAST(QUARTER(date_day) AS NUMBER(1,0))                                 AS quarter_num,
        CAST(CAST(YEAR(date_day) AS VARCHAR) 
            || '-Q' || CAST(QUARTER(date_day) AS VARCHAR) AS VARCHAR(8))       AS quarter_label,
        CAST(YEAR(date_day) AS NUMBER(4,0))                                    AS year,
        CAST(DAYNAME(date_day) AS VARCHAR(10))                                 AS day_of_week,
        CAST(MOD(DAYOFWEEK(date_day) + 5, 7) + 1 AS NUMBER(1,0))               AS day_of_week_num,
        
        CAST(CASE WHEN DAYOFWEEK(date_day) IN (1,7) THEN 1 ELSE 0 
             END AS NUMBER(1,0))                                              AS is_weekend,
        
        CAST(CASE WHEN date_day = LAST_DAY(date_day) THEN 1 ELSE 0 
             END AS NUMBER(1,0))                                              AS is_month_end,

        CAST(NULL AS VARCHAR(10))                                              AS fiscal_year,
        CAST(CURRENT_TIMESTAMP::TIMESTAMP_NTZ AS TIMESTAMP_NTZ)                AS dw_created_at
    FROM spine
)

SELECT * FROM attributes