{{
    config(materialized='incremental',
    unique_key='currency_sk',
     merge_exclude_columns = ['dw_created_at'], 
     tags=['dimension'])
}}

WITH src AS (
    SELECT * FROM {{ ref('STG_currency_master') }}
)

select 
    md5(src.currency_code_nk) as currency_sk,
    src.currency_code_nk AS currency_code_nk,
    src.description,
    CURRENT_TIMESTAMP as dw_created_at,
    {% if is_incremental() %}
    case when t.currency_sk  is null then null 
    else CURRENT_TIMESTAMP end as dw_updated_at
    {%else%}
    null as dw_updated_at
    {% endif %}
from src
{% if is_incremental() %}
left join {{ this }} t
on md5(src.currency_code_nk)=t.currency_sk
{% endif %}

