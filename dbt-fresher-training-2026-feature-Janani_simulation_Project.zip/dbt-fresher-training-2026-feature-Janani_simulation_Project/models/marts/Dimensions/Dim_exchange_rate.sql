{{
    config(materialized='incremental',
    unique_key='exch_rate_sk' ,
    tags=['dimension'])
}}

WITH src AS (
    SELECT * FROM {{ ref('snap_exchange_rate') }}
)

select exch_rate_sk,
       from_currency,
       to_currency,
       Rate_type,
       exchange_rate,
       effective_date_from,effective_date_to,
       dbt_valid_from as dw_created_at,
       dbt_valid_to  as  dw_updated_at
from src


