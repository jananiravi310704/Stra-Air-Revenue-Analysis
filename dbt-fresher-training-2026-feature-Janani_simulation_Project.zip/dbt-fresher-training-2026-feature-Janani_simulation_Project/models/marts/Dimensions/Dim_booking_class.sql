{{
    config(materialized='incremental',
    unique_key='booking_class_sk',
    merge_exclude_columns = ['dw_created_at'], 
    tags=['dimension'])
}}

WITH src AS (
    SELECT * FROM {{ ref('TF_booking_class') }}
)

select 
    md5(src.RBD_CODE_nk) as booking_class_sk,
    src.RBD_CODE_nk,
    src.RBD_Description,
    src.class_of_travel,
    src.cot_description,
    CURRENT_TIMESTAMP as dw_created_at,
      {% if is_incremental() %}
    case when t.booking_class_sk  is null then null 
    else CURRENT_TIMESTAMP end as dw_updated_at
    {%else%}
    null as dw_updated_at
    {% endif %}
from src
{% if is_incremental() %}
left join {{ this }} t 
on  md5(src.RBD_CODE_nk)= t.booking_class_sk
{% endif %}

