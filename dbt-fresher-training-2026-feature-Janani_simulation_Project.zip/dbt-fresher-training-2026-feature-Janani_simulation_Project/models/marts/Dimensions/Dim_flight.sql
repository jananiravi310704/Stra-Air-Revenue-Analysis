{{
    config(materialized='incremental', 
    unique_key='flight_sk',
     merge_exclude_columns = ['dw_created_at'],
     tags=['dimension'])
}}

WITH src AS (
    SELECT * FROM {{ ref('TF_flight') }}
)

SELECT
    md5(src.flight_no || '|' || src.flight_date_nk) as flight_sk,
    src.flight_number_nk,
    src.flight_date_nk,
    src.frm_airport_code as from_airport_code,
    src.to_airport_code,
    src.flight_type,
    src.flight_status,
    src.tail_no,
    src.first_seats,
    src.biz_seats,
    src.eco_seats,
    src.total_capacity,
    src.carrier_code,
    src.carrier_name,
    CURRENT_TIMESTAMP as dw_created_at,
    {% if is_incremental() %}
    case when t.flight_sk  is null then null 
    else CURRENT_TIMESTAMP end as dw_updated_at
    {%else%}
    null as dw_updated_at
    {% endif %}
from src
{% if is_incremental() %}
left join {{ this }} t
on md5(src.flight_no || '|' || src.flight_date_nk)=t.flight_sk
{% endif %}
