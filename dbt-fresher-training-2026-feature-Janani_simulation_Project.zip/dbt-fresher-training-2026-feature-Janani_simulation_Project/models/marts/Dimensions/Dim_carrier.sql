
{{
    config(materialized='incremental',
    unique_key= 'carrier_sk' ,
    merge_exclude_columns = ['dw_created_at'],
     tags=['dimension'])
}}

WITH src AS (SELECT * FROM {{ ref('STG_carrier_master') }})

select 
        MD5(TRIM(src.carrier_number_nk))  AS    carrier_sk,
        src.carrier_number_nk  ,
        src.carrier_code,
        src.airline_name,
        src.country,
           case 
                when src.carrier_number_nk=888 then 1
                else 0
           end as is_own_carrier,
        CURRENT_TIMESTAMP::TIMESTAMP_NTZ as dw_created_at,
    {% if is_incremental() %}
    case when t.carrier_sk  is null then null 
    else CURRENT_TIMESTAMP end as dw_updated_at
    {%else%}
    null as dw_updated_at
    {% endif %}
          
from src
{% if is_incremental() %}
left join {{ this }} t 
on  MD5(TRIM(src.carrier_number_nk))=t.carrier_sk
{% endif %}

