{{
    config(materialized='incremental', 
    unique_key='tax_code_sk',
     merge_exclude_columns = ['dw_created_at'],
     tags=['dimension'])
}}

WITH src AS (
    SELECT * FROM {{ ref('TF_tax') }}
)

select 
    md5(src.tax_code) as tax_code_sk,
    src.tax_code_nk,
    src.tax_description,
    src.tax_type,
    src.tax_type_description,
    src.country_code,
    src.country_name,
    CURRENT_TIMESTAMP as dw_created_at,
    {% if is_incremental() %}
    case when t.tax_code_sk  is null then null 
    else CURRENT_TIMESTAMP end as dw_updated_at
    {%else%}
    null as dw_updated_at
    {% endif %}
 
from src
{% if is_incremental() %}
left join {{ this }} t
on md5(src.tax_code)=t.tax_code_sk
{% endif %}
