{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH src AS (SELECT * FROM {{ ref('STG_CCD1') }})

SELECT
    airline_no,
    ticket_no,
    TRIM(invoice_no)        AS invoice_no,
    invoice_date,
    sale_currency_code,
    billing_currency_code,
    card_type,
    country_code,
    sale_refund,
    COALESCE(sale_value,    0) AS sale_value,
    COALESCE(billing_value, 0) AS billing_value,
    chargeback_amt,           
    chargeback_date,
    CASE TRIM(UPPER(card_type))
        WHEN 'VI'  THEN 'Credit Card'
        WHEN 'MC'  THEN 'Credit Card'
        WHEN 'AX'  THEN 'Credit Card'
        WHEN 'DC'  THEN 'Credit Card'
        WHEN 'CC'  THEN 'Credit Card'
        WHEN 'CSH' THEN 'Cash'
        WHEN 'IATA'THEN 'IATA'
        ELSE            'Other'
    END AS payment_category
FROM src