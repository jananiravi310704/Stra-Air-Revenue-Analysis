{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH coupon AS (
    SELECT * FROM {{ ref('STG_Coupon') }}
  where  carrier_code=888 
),

with_route AS (
    SELECT
        c.*,
        CASE
            WHEN c.from_airport IS NULL
              OR c.to_airport   IS NULL
                THEN 'UNK-UNK'
            ELSE TRIM(UPPER(c.from_airport))
                 || '-'
                 || TRIM(UPPER(c.to_airport))
        END                         AS airline_route
    FROM coupon c
)

SELECT
  *
FROM with_route