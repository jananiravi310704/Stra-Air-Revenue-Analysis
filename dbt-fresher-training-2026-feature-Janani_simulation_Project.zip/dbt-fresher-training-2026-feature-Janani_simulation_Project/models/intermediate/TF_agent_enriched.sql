
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH
agents   AS (SELECT * FROM {{ ref('STG_agent_sl') }}),
ctrl     AS (SELECT * FROM {{ ref('STG_controlling_locations') }}),
CITY AS (SELECT * FROM {{ ref('STG_city_master') }}),
countries AS (SELECT  * FROM {{ ref('STG_country_master') }})

SELECT
    
     a.agent_code_nk,
     a.agent_name,
     a.agent_city_code,
     city.city_name as agent_city_name,
     a.agent_address,
     a.location_type,
    cl.ctrl_loc_code,
    cl.ctrl_loc_name,
    cl.ctrl_loc_city_code                         AS ctrl_loc_city_code,
    CASE
        WHEN UPPER(cl.ctrl_loc_name) LIKE 'BSP%' THEN 'BSP'
        WHEN UPPER(cl.ctrl_loc_name) LIKE 'AO%'  THEN 'AO'
        WHEN UPPER(cl.ctrl_loc_name) LIKE 'GSA%'  THEN 'GSA'
        ELSE 'UNK'
    END                                  AS ctrl_loc_location_type,
    c.country_code as CTRL_LOC_COUNTRY_CODE,
    c.country_code                AS country_code,
    c.country_name                AS country_name
FROM agents a
LEFT JOIN ctrl cl
    ON a.ctrl_location= cl.ctrl_loc_code
LEFT JOIN CITY 
    ON a.agent_city_code  = city.city_code
left join  countries c
    on city.country_name=c.country_name
