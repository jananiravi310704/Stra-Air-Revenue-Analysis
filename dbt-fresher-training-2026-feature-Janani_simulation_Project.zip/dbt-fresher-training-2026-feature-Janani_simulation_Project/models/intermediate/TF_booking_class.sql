
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH
booking_class   AS (SELECT * FROM {{ ref('STG_booking_class') }}),
class_of_travel     AS (SELECT * FROM {{ ref('STG_Class_of_travel') }})

SELECT
    bc.RBD_CODE as RBD_CODE_nk ,
    bc.RBD_Description,
    cot.class_of_travel,
    cot.cot_description
   
FROM booking_class bc
LEFT JOIN class_of_travel cot
    ON bc.Class_of_Travel = cot.Class_of_Travel
