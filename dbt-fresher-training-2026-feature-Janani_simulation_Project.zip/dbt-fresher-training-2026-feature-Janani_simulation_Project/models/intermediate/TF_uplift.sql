
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH src AS (SELECT * FROM {{ ref('STG_Uplift') }})

SELECT
    ticket_number,
    coupon_number,
    carrier_code,
    flight_date,
    from_airport,
    to_airport,
    class_of_travel,           -- DEG dim on fact_boarding
    flight_no,
    1 AS pax_boarded_count     -- always 1 per boarding record
FROM src