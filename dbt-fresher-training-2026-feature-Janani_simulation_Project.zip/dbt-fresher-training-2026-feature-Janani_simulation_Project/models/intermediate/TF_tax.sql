
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH
TAX   AS (SELECT * FROM {{ ref('STG_Tax_master') }}),
Tax_type     AS (SELECT * FROM {{ ref('STG_Tax_type_master') }}),
Country     AS (SELECT * FROM {{ ref('STG_country_master') }})


SELECT
    t.tax_code,
    T.tax_code as tax_code_nk,
    T.description as tax_description,
    tt.tax_type,
    tt.tax_type_description,
    c.country_code,
    c.country_name
   
FROM TAX T
LEFT JOIN Tax_type TT 
    ON t.type=tt.tax_type
LEFT JOIN Country c
    on t.country_code=c.country_code
