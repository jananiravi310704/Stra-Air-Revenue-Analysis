
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH
airport   AS (SELECT * FROM {{ ref('STG_airport') }}),
city     AS (SELECT * FROM {{ ref('STG_city_master') }}),
country     AS (SELECT * FROM {{ ref('STG_country_master') }})


SELECT
        a.airport_code,
        a.airport_code as airport_code_nk,
        a.airport_name,
        c.city_code,
        c.city_name,
        co.country_number,
        co.country_code,
        co.country_name

FROM airport a
LEFT JOIN city c
    on a.city_code=c.city_code
LEFT JOIN country co
   on a.country_code=co.country_code

