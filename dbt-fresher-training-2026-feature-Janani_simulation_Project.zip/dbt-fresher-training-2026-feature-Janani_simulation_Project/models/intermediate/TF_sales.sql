{{
    config(
        materialized='incremental',
        unique_key='ticket_number'
    )
}}

with sales as (SELECT
                        s.ticket_number,
                        s.carrier_code,
                        s.sale_date,
                        s.agent_code,
                        s.sales_currency,
                        s.tax_code_1,
                        s.tax_code_2,
                        s.tax_code_3,
                        s.fop_1_code,
                        s.fop_2_code,
                        s.fop_3_code,
                        s.ticket_amount          AS ticket_amt_sale,
                        s.commission_amount      AS commission_amt_sale,
                        s.discount_amount        AS discount_amt_sale,
                        s.tax_1_amount           ,
                        s.tax_2_amount            ,
                        s.tax_3_amount           ,
                        s.tax_amount             AS tax_total_amount,
                        s.fop_1_amount           ,
                        s.fop_2_amount           ,
                        s.fop_3_amount           ,
                        s.flight_year_quarter
                    FROM {{ ref('STG_Sales') }} s
                    where COALESCE(s.ticket_amount, 0) > 0
                    {% if is_incremental() %}
                        -- this filter will only be applied on an incremental run
                        and sale_date > (select max(sale_date) from {{ this }}) 
                    {% endif %}
                    
                    ),
coupon_airports AS (
                    SELECT DISTINCT
                        ticket_number,
                        from_airport,
                        to_airport
                    FROM {{ ref('STG_Coupon') }}
                    where ticket_number in (select ticket_number from sales)and carrier_code=888),
airport AS (
            SELECT airport_code, country_code
            FROM {{ ref('STG_airport') }}
)
,
 with_tax_flag AS (
    SELECT
        *,
        CASE
            WHEN ABS(
                COALESCE(tax_1_amount,0)
              + COALESCE(tax_2_amount,0)
              + COALESCE(tax_3_amount,0)
              - COALESCE(tax_total_amount,0)
            ) >=0.01 THEN 1
            ELSE 0
        END AS tax_reconciliation_flag
    FROM sales
),
with_ticket_type AS (
    SELECT
        t.*,
        ca.from_airport,
        ca.to_airport,
        org.country_code AS origin_country_code,
        dest.country_code AS dest_country_code,
        CASE
            WHEN org.country_code IS NULL
              OR dest.country_code IS NULL  THEN 'UNKNOWN'
            WHEN org.country_code
               = dest.country_code         THEN 'DOMESTIC'
            ELSE                                'INTERNATIONAL'
        END AS ticket_type
    FROM with_tax_flag t
    LEFT JOIN coupon_airports ca
        ON t.ticket_number = ca.ticket_number
    LEFT JOIN airport org
        ON ca.from_airport = org.airport_code
    LEFT JOIN airport dest
        ON ca.to_airport   = dest.airport_code)

select * from with_ticket_type