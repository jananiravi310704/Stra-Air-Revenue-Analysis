
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH
exchange_rate   AS (SELECT * FROM {{ ref('STG_Currency_exchange') }})


SELECT  md5(e.from_currency || '|' || e.To_currency || '|' || e.effective_date_from  ) as exch_rate_sk,
        e.from_currency,e.To_currency,
        e.Rate_type,
        e.Exchange_Rate,
        e.effective_date_from,
        e.effective_date_to

FROM exchange_rate e
{% if is_incremental() %}
left join {{ this }} t
on md5(e.from_currency || '|' || e.To_currency || '|' || e.effective_date_from  )=t.exch_rate_sk
{% endif %}

