
{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH
flight   AS (SELECT * FROM {{ ref('stg_flight_master') }}),
carrier     AS (SELECT * FROM {{ ref('STG_carrier_master') }})



SELECT
    f.flight_no,
    (f.flight_no) as flight_number_nk,
    (f.flight_date) as flight_date_nk,
    f.frm_airport_code,
    f.to_airport_code,
    f.flight_type,
    f.flight_status,
    f.tail_no,
    f.first as first_seats,
    f.business as biz_seats,
    f.economy as eco_seats,
    ((f.first) + (f.business) + (f.economy)) as total_capacity,
    c.carrier_code,
    c.airline_name as carrier_name 

FROM flight f
LEFT JOIN carrier c
    ON f.carrier=c.carrier_number_nk

