{{
    config(
        materialized = 'table',
        tags         = ['intermediate']
    )
}}

WITH src AS (SELECT * FROM {{ ref('STG_Inward') }})


SELECT
    ticket_no,
    coupon_no,
    carrier_code,
    billed_carrier_code,
    billed_date,
    billed_currency,
    CASE stage
        WHEN 1 THEN 'ACCEPTED'
        ELSE        'UNKNOWN'
    END AS dispute_stage,
     billed_coupon_amt,
    billed_commission_amt,
     billed_discount_amt,
    accepted_coupon_amt,
     accepted_commission_amt,
     accepted_discount_amt,
     rejected_coupon_amt,
    rejected_commission_amt,
    rejected_discount_amt
FROM src
