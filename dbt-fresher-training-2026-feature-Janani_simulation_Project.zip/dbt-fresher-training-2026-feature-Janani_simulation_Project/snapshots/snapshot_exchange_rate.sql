{% snapshot snap_exchange_rate %}
    {{
        config(
            target_schema='simulation_08_STAGE',
            target_database='dbt_training',
            unique_key='exch_rate_sk',
            strategy='check',
            check_cols    = ['exchange_rate_value', 'effective_to', 'to_currency'],
            tags=['dimension'],
            invalidate_hard_deletes = False
        )
    }}

    select     *
    from {{ ref('TF_exchange_rate') }}
 {% endsnapshot %}