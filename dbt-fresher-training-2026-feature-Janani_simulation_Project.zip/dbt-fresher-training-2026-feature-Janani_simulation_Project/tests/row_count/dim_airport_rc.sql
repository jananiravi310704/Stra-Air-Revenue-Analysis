with source_count as ( 
    select count(*) as source_cnt 
    from {{ source('starair', 'AIRPORT_MASTER') }}
), 

target_count as ( 
    select count(*) as target_cnt 
    from {{ ref('Dim_airport') }} 
) 

select 
    source_cnt,
    target_cnt
from source_count
cross join target_count 
where source_cnt != target_cnt