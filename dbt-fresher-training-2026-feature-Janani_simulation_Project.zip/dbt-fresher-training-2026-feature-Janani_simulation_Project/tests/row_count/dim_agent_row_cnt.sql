with source_count as ( 
    select count(*) as source_cnt 
    from {{ source('starair', 'AGENT_SL_MASTER') }}
), 

target_count as ( 
    select count(*) as target_cnt 
    from {{ ref('Dim_agent') }} 
) 

select 
    source_cnt,
    target_cnt
from source_count
cross join target_count 
where source_cnt != target_cnt