with source_count as ( 
    select count(*) as source_cnt 
    from {{ source('starair', 'FLIGHT_MASTER') }}
), -- <-- Removed the extra closing parenthesis from here

target_count as ( 
    select count(*) as target_cnt 
    from {{ ref('Dim_flight') }} 
) 

select 
    source_cnt,
    target_cnt
from source_count
cross join target_count 
where source_cnt != target_cnt