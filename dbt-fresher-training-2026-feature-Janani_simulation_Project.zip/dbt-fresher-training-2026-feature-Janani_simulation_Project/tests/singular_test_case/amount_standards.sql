select 
    ticket_number_nk,
    ticket_amt_base,
    tax_total_amt
from {{ ref('fact_sales') }}
where ticket_amt_base < 0 
   or tax_total_amt < 0