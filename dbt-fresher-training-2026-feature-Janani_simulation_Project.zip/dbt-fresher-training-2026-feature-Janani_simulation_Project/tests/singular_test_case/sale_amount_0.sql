SELECT ticket_sk, ticket_amt_sale
FROM {{ ref('fact_sales') }}
WHERE COALESCE(ticket_amt_sale, 0) = 0
