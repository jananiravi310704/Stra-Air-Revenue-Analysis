
SELECT
    ticket_sk,
    ticket_number_nk,
    tax_1_amt,
    tax_2_amt,
    tax_3_amt,
    tax_total_amt,
    ABS((tax_1_amt + tax_2_amt + tax_3_amt) - tax_total_amt) AS tax_variance
FROM {{ ref('fact_sales') }}
WHERE ABS((COALESCE(tax_1_amt, 0) + COALESCE(tax_2_amt, 0) + COALESCE(tax_3_amt, 0)) - tax_total_amt) > 0.01
  AND tax_reconciliation_flag = 0 