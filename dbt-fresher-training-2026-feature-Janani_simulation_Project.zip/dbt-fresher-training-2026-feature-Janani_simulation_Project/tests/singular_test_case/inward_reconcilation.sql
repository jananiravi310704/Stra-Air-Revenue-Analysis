SELECT ticket_number_nk, billed_coupon_amt,
       accepted_coupon_amt, rejected_coupon_amt,
       ABS(billed_coupon_amt - accepted_coupon_amt - rejected_coupon_amt) AS variance
FROM {{ ref('Fact_interline') }}
WHERE ABS(billed_coupon_amt - accepted_coupon_amt - rejected_coupon_amt) > 0.01