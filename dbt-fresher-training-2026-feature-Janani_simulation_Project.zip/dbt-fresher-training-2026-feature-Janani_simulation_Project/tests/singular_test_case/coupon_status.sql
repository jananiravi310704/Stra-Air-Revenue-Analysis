SELECT segment_sk, coupon_status
FROM {{ ref('fact_coupon') }}
WHERE coupon_status  not in ('F','I')
