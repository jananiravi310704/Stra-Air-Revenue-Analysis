select carrier_sk, count(*) 

from {{ ref('Dim_carrier') }} 

group by carrier_sk 

having count(*) >1 