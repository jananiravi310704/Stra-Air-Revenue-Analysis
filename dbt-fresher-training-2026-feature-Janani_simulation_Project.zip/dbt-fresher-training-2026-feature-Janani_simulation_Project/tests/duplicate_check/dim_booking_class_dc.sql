select booking_class_sk, count(*) 

from {{ ref('Dim_booking_class') }} 

group by booking_class_sk 

having count(*) >1 