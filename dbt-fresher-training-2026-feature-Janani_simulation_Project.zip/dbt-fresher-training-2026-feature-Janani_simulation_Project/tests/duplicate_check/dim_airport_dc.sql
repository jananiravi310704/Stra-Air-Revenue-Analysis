select airport_sk, count(*) 

from {{ ref('Dim_airport') }} 

group by airport_sk 

having count(*) >1 