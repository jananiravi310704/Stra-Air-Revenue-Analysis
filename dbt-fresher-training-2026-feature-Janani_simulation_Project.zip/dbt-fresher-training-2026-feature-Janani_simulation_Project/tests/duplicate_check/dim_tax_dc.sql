select Tax_code_sk, count(*) 

from {{ ref('Dim_tax') }} 

group by Tax_code_sk 

having count(*) >1 