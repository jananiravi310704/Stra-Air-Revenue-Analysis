select exch_rate_sk, count(*) 

from {{ ref('Dim_exchange_rate') }} 

group by exch_rate_sk 

having count(*) >1 