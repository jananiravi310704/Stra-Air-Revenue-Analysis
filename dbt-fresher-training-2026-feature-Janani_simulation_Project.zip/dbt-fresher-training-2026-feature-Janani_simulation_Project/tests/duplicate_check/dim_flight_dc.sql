select flight_sk, count(*) 

from {{ ref('Dim_flight') }} 

group by flight_sk 

having count(*) >1 