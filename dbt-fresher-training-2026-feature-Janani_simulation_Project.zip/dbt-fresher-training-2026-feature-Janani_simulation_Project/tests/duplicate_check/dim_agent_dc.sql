select agent_sk, count(*) 

from {{ ref('Dim_agent') }} 

group by agent_sk 

having count(*) >1 