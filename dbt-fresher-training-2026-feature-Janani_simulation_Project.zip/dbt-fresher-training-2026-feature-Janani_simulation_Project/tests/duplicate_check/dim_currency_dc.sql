select currency_sk, count(*) 

from {{ ref('Dim_currency') }} 

group by currency_sk 

having count(*) >1 